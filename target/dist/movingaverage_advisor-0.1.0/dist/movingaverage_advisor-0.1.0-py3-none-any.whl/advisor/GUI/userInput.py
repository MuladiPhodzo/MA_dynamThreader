import tkinter as tk
from tkinter import messagebox
import ttkbootstrap as tb
from ttkbootstrap.constants import *

class UserGUI:
    def __init__(self):
        self.root = tb.Window(themename="cosmo")  # modern theme
        self.root.title("🚀 Trading Bot Setup")
        self.root.geometry("500x450")

        self.user_data = {}
        self.should_run = None

        self.setup_gui()
        self.root.mainloop()

    def setup_gui(self):
        # Main Frame
        main_frame = tb.Frame(self.root, padding=20)
        main_frame.pack(fill="both", expand=True)

        # Title
        tb.Label(main_frame, text="Trading Bot Setup",
                 font=("Segoe UI", 16, "bold")).pack(pady=(0, 15))

        # --- Trading Setup ---
        trading_frame = tb.Labelframe(main_frame, text="⚙️ Trading Setup", padding=10)
        trading_frame.pack(fill="x", pady=10)

        self.volume = tb.Spinbox(trading_frame, from_=0.01, to=5.0, increment=0.01, width=10)
        self._add_field(trading_frame, "Volume", self.volume)

        self.sl = tb.Spinbox(trading_frame, from_=1, to=1000, increment=1, width=10)
        self._add_field(trading_frame, "SL Distance", self.sl)

        self.rr = tb.Combobox(trading_frame, values=["1:1", "1:2", "1:3", "1:5"], width=10)
        self.rr.current(2)
        self._add_field(trading_frame, "RR Ratio", self.rr)

        self.timeframes = tb.Combobox(trading_frame, values=["1M", "5M", "15M", "1H", "4H", "1D"], width=10)
        self.timeframes.current(3)
        self._add_field(trading_frame, "Timeframe", self.timeframes)

        # --- Account Info ---
        account_frame = tb.Labelframe(main_frame, text="👤 Account Info", padding=10)
        account_frame.pack(fill="x", pady=10)

        self.server = tb.Entry(account_frame, width=25)
        self._add_field(account_frame, "Server", self.server)

        self.account_id = tb.Entry(account_frame, width=25)
        self._add_field(account_frame, "Account ID", self.account_id)

        self.password = tb.Entry(account_frame, show="●", width=25)
        self._add_field(account_frame, "Password", self.password)

        # Buttons
        btn_frame = tb.Frame(main_frame)
        btn_frame.pack(pady=15)

        tb.Button(btn_frame, text="▶ Run", bootstyle=SUCCESS, command=self.submit).pack(side="left", padx=10)
        tb.Button(btn_frame, text="❌ Cancel", bootstyle=DANGER, command=self.quit).pack(side="left", padx=10)

        # Status Bar
        self.status = tb.Label(self.root, text="Ready", bootstyle=INFO, anchor="w")
        self.status.pack(side="bottom", fill="x")

    def _add_field(self, parent, label, widget):
        frame = tb.Frame(parent)
        frame.pack(fill="x", pady=5)
        tb.Label(frame, text=label, width=15, anchor="e").pack(side="left", padx=5)
        widget.pack(side="left", padx=5)

    def submit(self):
        if not self.account_id.get().isdigit():
            messagebox.showerror("Error", "Account ID must be numeric.")
            return

        self.user_data = {
            "volume": float(self.volume.get()),
            "sl": int(self.sl.get()),
            "rr": self.rr.get(),
            "tf": self.timeframes.get(),
            "server": self.server.get(),
            "account_id": self.account_id.get(),
            "password": self.password.get()
        }
        self.status.config(text="✅ Bot Ready!")
        self.root.withdraw()
        self.should_run = True
        return self.user_data

    def quit(self):
        self.status.config(text="🛑 Bot Stopped")
        self.root.quit()
